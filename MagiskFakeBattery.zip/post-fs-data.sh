#!/system/bin/sh
MODDIR=${0%/*}

# 延迟启动，确保系统电源管理初始化
sleep 5

# 后台守护函数
keep_battery_fixed() {
    while true; do
        # 设置电量 98%
        dumpsys battery set level 98
        # 设置状态为充电中 (2 = Charging)
        dumpsys battery set status 2
        # optional: 设置电压、温度，让系统认为是真的
        dumpsys battery set voltage 4200
        dumpsys battery set temperature 300
        # 等待 5 秒再重复
        sleep 5
    done
}

# 启动后台守护
keep_battery_fixed &

# 记录日志
echo "[FakeBattery] Battery daemon started, keeping 98% and charging" > /data/local/tmp/fakebattery.log
