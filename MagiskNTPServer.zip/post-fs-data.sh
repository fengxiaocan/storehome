#!/system/bin/sh
MODDIR=${0%/*}

# 延迟启动，确保系统挂载完成
sleep 5

# 设置系统 NTP 服务器
NTP_SERVER="ntp.ntsc.ac.cn"

# 使用 settings 命令修改全局 NTP 服务器
settings put global ntp_server "$NTP_SERVER"

# 确认生效
current_ntp=$(settings get global ntp_server)
echo "[NTPServer] Current NTP server: $current_ntp" > /data/local/tmp/ntpserver.log

# 提示日志
echo "[NTPServer] NTP server set to $NTP_SERVER" >> /data/local/tmp/ntpserver.log
