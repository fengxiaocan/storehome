#!/system/bin/sh
# Magisk 安装阶段执行（非必须）

ui_print "Creating swapfile..."
dd if=/dev/zero of=/data/swapfile bs=1M count=4096
chmod 600 /data/swapfile
mkswap /data/swapfile
swapon -p 1000 $SWAP_PATH
ui_print "Swapfile created."
