#!/system/bin/sh
# 设置 swap 为 4GB

SWAP_PATH="/data/swapfile"
SWAP_SIZE_MB=4096

# 检查是否已有 swap
if grep -q "swapfile" /proc/swaps; then
    echo "[MagiskSwap] swapfile already active"
    exit 0
fi

# 若文件不存在则创建
if [ ! -f "$SWAP_PATH" ]; then
    echo "[MagiskSwap] Creating $SWAP_PATH ($SWAP_SIZE_MB MB)"
    dd if=/dev/zero of=$SWAP_PATH bs=1M count=$SWAP_SIZE_MB
    chmod 600 $SWAP_PATH
    mkswap $SWAP_PATH
fi

# 启用 swap
swapon -p 1000 $SWAP_PATH
echo "[MagiskSwap] swap enabled successfully"
