#!/system/bin/sh
MODDIR=${0%/*}

# 延迟启动，确保系统挂载完成
sleep 10

APK_NAME="Xplore.apk"
PKG_NAME="com.lonelycatgames.Xplore"
SYSTEM_APP_DIR="/system/priv-app/Xplore"

echo "[SystemXplore] Module started" > /data/local/tmp/systemxplore.log

# 检查 APK 是否存在
if [ ! -f "$MODDIR/system/priv-app/Xplore/$APK_NAME" ]; then
    echo "[SystemXplore] APK not found in module folder!" >> /data/local/tmp/systemxplore.log
    exit 1
fi

# 使用 Magisk overlay 挂载到系统路径
mkdir -p "$SYSTEM_APP_DIR"
cp -f "$MODDIR/system/priv-app/Xplore/$APK_NAME" "$SYSTEM_APP_DIR/"
chmod 644 "$SYSTEM_APP_DIR/$APK_NAME"
chown root:root "$SYSTEM_APP_DIR/$APK_NAME"
echo "[SystemXplore] APK mounted to system path" >> /data/local/tmp/systemxplore.log

# 等待 PackageManager 扫描
sleep 5

# 授予系统权限
permissions=(
    android.permission.WRITE_SECURE_SETTINGS
    android.permission.SYSTEM_ALERT_WINDOW
    android.permission.WRITE_EXTERNAL_STORAGE
    android.permission.READ_EXTERNAL_STORAGE
    android.permission.FOREGROUND_SERVICE
    android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS
)

for perm in "${permissions[@]}"; do
    pm grant $PKG_NAME $perm 2>/dev/null
done

echo "[SystemXplore] Granted system-level permissions" >> /data/local/tmp/systemxplore.log

# 可选：保持 root 权限（依赖 Magisk Manager 授权）
echo "[SystemXplore] Ensure user grants root permission in Magisk Manager" >> /data/local/tmp/systemxplore.log
