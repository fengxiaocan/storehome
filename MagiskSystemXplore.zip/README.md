简介：可以把 com.lonelycatgames.Xplore 升级为系统应用，授予所有系统级权限
1.把原来的 Xplore.apk 放入 system/priv-app/Xplore/ 文件夹。
2.打包整个 MagiskSystemXplore 文件夹为 ZIP（保留结构）。
3.在 Magisk Manager 中选择 安装来自存储 → 选择这个 ZIP。
4.重启设备。
